# BigData

Note this our mongodb is localhost on port 27017 so the query will work only in our localhost!
we create a mongodb with the file 'movie_titles.csv' with db name 'NetflixMovies' on collection 'movies'.
but in file 'server.js' you can see the code for create the server and the connection to mongodb + the query!.
we use the 'ejs' approch to update the webform, the file is in '/views/index.ejs'.

1) to run the server you should run on terminal:
   cd /BigData	
   node server.js
2) go to your browser and enter:
   127.0.0.1:8080
3) search for your movies by Name or Year!

Thank for using our service.
Eliran Kasif && Noy Simantov && Or Azulay.
